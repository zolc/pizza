﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaProblem
{
    public class Rectangle
    {
        public int x; public int y;
        public int height; public int length;
        public Rectangle(int _x, int _y, int _h, int _l)
        {
            x = _x;
            y = _y;
            height = _h;
            length = _l;
        }
    }
}
